SOURCE_DOC = "Azure Security and Compliance Blueprint - FedRAMP High SSP.docx"
